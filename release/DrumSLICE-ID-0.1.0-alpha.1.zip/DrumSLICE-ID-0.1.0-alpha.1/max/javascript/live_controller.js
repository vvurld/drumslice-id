/* global LiveAPI, Dict, Task, include, arrayfromargs, messagename, outlet, post */
"use strict";

autowatch = 1;
inlets = 2;
outlets = 3;
var V = DrumSliceIDValues;
var Naming = DrumSliceIDNaming;
var STATES = {INITIALIZING: 1, NO_RACK: 1, READY_TO_SCAN: 1, SCANNING: 1, SCAN_READY: 1, ANALYZING: 1, REVIEW_READY: 1, APPLYING: 1, APPLIED: 1, CANCELLING: 1, ERROR: 1};
var state = "INITIALIZING";
var trackPath = "";
var targetRackIndex = 0;
var rackCandidates = [];
var snapshot = null;
var plan = null;
var chainByRegion = {};
var lastApply = null;
var activeAnalysisJobId = null;
var activeAnalysisSettings = null;
var overwriteConflicts = false;
var analysisSettings = {backend: "adtof", modelOptions: {device: "cpu", fps: 100, maxThreads: 2, thresholds: {kick: 0.22, snare: 0.24, tom: 0.32, hihat: 0.22, cymbal: 0.30}}, mappingOptions: {preToleranceMs: 35, postToleranceMs: 90, clusterMs: 18, multiLabel: true, fallbackEnabled: true, fallbackNormalizedFloor: 0.70}, namingOptions: {numbering: "duplicates", longNames: false, preserveUnknown: false}};

function emitStatus(code, message, details) {
    /* Keep the structured status event for diagnostics/tests and publish a
       display-only event so the patch never has to parse Max selectors. */
    outlet(0, "status", code, message);
    outlet(0, "display_status", message);
    if (details) { outlet(2, "diagnostic", JSON.stringify(details)); }
}
function setState(next) {
    var revertBusy;
    if (!STATES[next]) { throw new Error("Unknown state " + next); }
    state = next;
    outlet(0, "state", next);
    /* Revert availability is orthogonal to analysis readiness. A rescan keeps
       the last verified Apply record, so deriving this button solely from the
       SCAN_READY/APPLIED state would hide a still-valid Revert operation. */
    revertBusy = next === "SCANNING" || next === "ANALYZING" || next === "CANCELLING" || next === "APPLYING";
    outlet(0, "revert_available", !revertBusy && lastApply && lastApply.writes && lastApply.writes.length ? 1 : 0);
}
function countLabel(count, singular, plural) { return count + " " + (count === 1 ? singular : plural); }
/* Do not name this function `error`: Node for Max sends an `error` selector,
   and Max dispatches matching selectors directly to global JS functions. */
function fail(code, message, details) { setState(lastApply && lastApply.writes && lastApply.writes.length ? "APPLIED" : "ERROR"); emitStatus(code, message, details); }
function makeApi(pathOrId) { var api = new LiveAPI(null); if (typeof pathOrId === "number") { api.id = pathOrId; } else { api.path = pathOrId; } return api; }
function get(api, property) { try { return api.get(property); } catch (exception) { return null; } }
function apiPath(api) { try { return String(api.path); } catch (exception) { return ""; } }
function apiType(api) { try { return String(api.type); } catch (exception) { return ""; } }
function unquoteApiPath(value) { value = String(value || ""); return value.length >= 2 && value.charAt(0) === '"' && value.charAt(value.length - 1) === '"' ? value.slice(1, -1) : value; }
function newId() { return V.sha256(String(new Date().getTime()) + ":" + String(Math.random()) + ":" + String(new Date().getMilliseconds())).slice(0, 32); }

function initialized() {
    var device, track;
    if (state !== "INITIALIZING" && state !== "ERROR") { return; }
    try {
        device = makeApi("this_device");
        if (!device.id) { fail("DEVICE_NOT_READY", "DrumSLICE ID is waiting for Live to initialize the device."); return; }
        track = makeApi("this_device canonical_parent");
        if (apiType(track) !== "Track") { fail("NOT_ON_MIDI_TRACK", "Place DrumSLICE ID on a MIDI track."); return; }
        trackPath = apiPath(track);
        discoverRacks();
    } catch (exception) { fail("LIVE_API_INITIALIZATION_FAILED", "Could not initialize the Live connection.", {message: String(exception)}); }
}

function discoverRacks() {
    var previousRack = rackCandidates[targetRackIndex], device = makeApi("this_device"), devicePath = apiPath(device), track = makeApi("this_device canonical_parent"), resolvedTrackPath = apiPath(track), normalizedDevicePath, normalizedTrackPath, ids, current = -1, pathMatch, fallbackIndex, previousIndex = -1, i, candidate, drum, hasDrumPads;
    if (apiType(track) !== "Track" || !resolvedTrackPath) { fail("NOT_ON_MIDI_TRACK", "Place DrumSLICE ID on a MIDI track."); return; }
    /* The device may have moved since initialization. Never reuse the old
       track path when resolving downstream devices. */
    trackPath = resolvedTrackPath;
    normalizedDevicePath = unquoteApiPath(devicePath); normalizedTrackPath = unquoteApiPath(trackPath);
    ids = V.idList(get(track, "devices"));
    rackCandidates = [];
    for (i = 0; i < ids.length; i += 1) {
        candidate = makeApi(ids[i]);
        if (ids[i] === Number(device.id) || (devicePath && apiPath(candidate) === devicePath)) { current = i; break; }
    }
    /* Some Live/Max combinations expose a valid this_device ID before the
       track's device-ID list has caught up.  The canonical path still carries
       the stable zero-based device index, so use it as a safe fallback. */
    if (current < 0 && devicePath) {
        pathMatch = /(?:^|\s)devices\s+(\d+)(?:\s|$)/.exec(normalizedDevicePath);
        fallbackIndex = pathMatch ? Number(pathMatch[1]) : -1;
        if (fallbackIndex >= 0 && fallbackIndex < ids.length && normalizedDevicePath === normalizedTrackPath + " devices " + fallbackIndex) { current = fallbackIndex; }
    }
    if (current < 0) { fail("DEVICE_NOT_ON_TRACK", "DrumSLICE ID could not resolve its position on the track.", {deviceId: Number(device.id), devicePath: devicePath, trackPath: trackPath, trackDeviceIds: ids}); return; }
    for (i = current + 1; i < ids.length; i += 1) {
        candidate = makeApi(ids[i]); drum = V.number(get(candidate, "can_have_drum_pads"), 0); hasDrumPads = get(candidate, "has_drum_pads");
        if (drum === 1 && (hasDrumPads == null || V.number(hasDrumPads, 0) === 1)) { rackCandidates.push({id: ids[i], path: apiPath(candidate), name: V.string(get(candidate, "name")), deviceIndex: i, downstreamOffset: i - current}); }
    }
    outlet(0, "rack_menu_clear");
    for (i = 0; i < rackCandidates.length; i += 1) { outlet(0, "rack_menu_append", rackCandidates[i].name + " · +" + rackCandidates[i].downstreamOffset); }
    if (!rackCandidates.length) { setState("NO_RACK"); emitStatus("NO_DOWNSTREAM_DRUM_RACK", "Place DrumSLICE ID before a Drum Rack on the same MIDI track."); return; }
    if (previousRack) {
        for (i = 0; i < rackCandidates.length; i += 1) {
            if (Number(rackCandidates[i].id) === Number(previousRack.id)) { previousIndex = i; break; }
        }
        if (previousIndex < 0 && previousRack.path) {
            for (i = 0; i < rackCandidates.length; i += 1) { if (rackCandidates[i].path === previousRack.path) { previousIndex = i; break; } }
        }
    }
    targetRackIndex = previousIndex >= 0 ? previousIndex : Math.max(0, Math.min(Number(targetRackIndex) || 0, rackCandidates.length - 1)); setState("READY_TO_SCAN"); emitStatus("READY", "Ready · " + rackCandidates[targetRackIndex].name);
}

function selectrack(index) {
    index = Number(index);
    if (state === "APPLYING") { emitStatus("BUSY_APPLYING", "Wait for the current Apply operation to finish before selecting another rack."); return; }
    if (index >= 0 && index < rackCandidates.length) {
        if (state === "ANALYZING" || state === "CANCELLING") { outlet(1, "cancel"); }
        activeAnalysisJobId = null; activeAnalysisSettings = null; targetRackIndex = index; snapshot = null; plan = null; chainByRegion = {};
        setState("READY_TO_SCAN");
    }
}

function findReachableSimplers(chainId, maxDepth) {
    var matches = [], warnings = [], visited = {}, incomplete = false, walkChain, walkDevice;
    maxDepth = maxDepth == null ? 8 : maxDepth;
    walkChain = function (id, depth) {
        var chain, devices, i;
        if (depth > maxDepth) { incomplete = true; warnings.push("Maximum nested rack depth reached."); return; }
        if (visited[id]) { incomplete = true; warnings.push("Repeated Live object encountered during traversal."); return; }
        visited[id] = true; chain = makeApi(id);
        if (!chain.id) { incomplete = true; warnings.push("A nested chain disappeared during traversal."); return; }
        try { devices = V.idList(chain.get("devices")); }
        catch (exception) { incomplete = true; warnings.push("Could not read devices from a nested chain."); return; }
        for (i = 0; i < devices.length; i += 1) { walkDevice(devices[i], depth); }
    };
    walkDevice = function (id, depth) {
        var device = makeApi(id), type, canHaveChains, chains, i;
        if (!device.id) { incomplete = true; warnings.push("A nested device disappeared during traversal."); return; }
        try { type = String(device.type); }
        catch (exception) { incomplete = true; warnings.push("Could not read a nested device type."); return; }
        if (type === "SimplerDevice") { matches.push({id: id, path: apiPath(device)}); return; }
        try { canHaveChains = V.number(device.get("can_have_chains"), 0); }
        catch (exception) { incomplete = true; warnings.push("Could not determine whether a nested device contains chains."); return; }
        if (canHaveChains === 1) {
            try { chains = V.idList(device.get("chains")); }
            catch (exception) { incomplete = true; warnings.push("Could not read chains from a nested rack."); return; }
            for (i = 0; i < chains.length; i += 1) { walkChain(chains[i], depth + 1); }
        }
    };
    walkChain(chainId, 0); return {matches: matches, warnings: warnings, incomplete: incomplete};
}

function extractRegion(jobId, rack, pad, padIndex, chainId) {
    var chain = makeApi(chainId), found = findReachableSimplers(chainId, 8), simpler, sampleIds, sample, path, rate, length, start, end, playback, multi, regionId, padNote;
    padNote = V.number(get(pad, "note"), padIndex);
    if (found.incomplete) { return {skip: {padNote: padNote, reasonCode: "INCOMPLETE_SIMPLER_TRAVERSAL", message: "Nested rack traversal was incomplete, so exactly one reachable Simpler could not be proven."}}; }
    if (found.matches.length === 0) { return {skip: {padNote: V.number(get(pad, "note"), padIndex), reasonCode: "NO_SIMPLER", message: "Pad contains no reachable Simpler device."}}; }
    if (found.matches.length > 1) { return {skip: {padNote: V.number(get(pad, "note"), padIndex), reasonCode: "MULTIPLE_SIMPLERS", message: "Pad contains more than one reachable Simpler device."}}; }
    simpler = makeApi(found.matches[0].id); multi = V.number(get(simpler, "multi_sample_mode"), 0);
    if (multi === 1) { return {skip: {padNote: V.number(get(pad, "note"), padIndex), reasonCode: "MULTISAMPLE_SIMPLER", message: "Pad uses unsupported Simpler multisample mode."}}; }
    sampleIds = V.idList(get(simpler, "sample"));
    if (sampleIds.length !== 1) { return {skip: {padNote: V.number(get(pad, "note"), padIndex), reasonCode: "INVALID_SAMPLE", message: "Simpler does not expose exactly one Sample object."}}; }
    sample = makeApi(sampleIds[0]);
    path = V.string(get(sample, "file_path")); rate = V.number(get(sample, "sample_rate"), 0); length = V.number(get(sample, "length"), 0); start = V.number(get(sample, "start_marker"), -1); end = V.number(get(sample, "end_marker"), -1); playback = V.number(get(simpler, "playback_mode"), -1);
    if (!path) { return {skip: {padNote: V.number(get(pad, "note"), padIndex), reasonCode: "UNREADABLE_SAMPLE_PATH", message: "Sample has no readable backing file path."}}; }
    if (rate <= 0 || length <= 0 || start < 0 || end <= start || start >= length || end > length) { return {skip: {padNote: V.number(get(pad, "note"), padIndex), reasonCode: "INVALID_SAMPLE_REGION", message: "rate=" + rate + " length=" + length + " start=" + start + " end=" + end}}; }
    regionId = V.sha256(jobId + "\0" + padNote + "\0" + chainId + "\0" + path + "\0" + start + "\0" + end);
    chainByRegion[regionId] = {rackId: Number(rack.id), rackPath: apiPath(rack), padId: Number(pad.id), padNote: padNote, chainId: chainId, chainPath: apiPath(chain)};
    return {region: {regionId: regionId, padIndex: padIndex, padNote: padNote, padDisplayName: V.string(get(pad, "name")), chainSessionId: chainId, chainSessionPath: apiPath(chain), originalChainName: V.string(get(chain, "name")), simplerSessionPath: found.matches[0].path, playbackMode: playback, source: {path: path, sampleRate: rate, lengthFrames: length, startFrame: start, endFrame: end}, warnings: found.warnings}};
}

function scan() {
    var rack, pad, padIds, chains, i, result, jobId, sourceSeen = {}, reasonCounts = {}, summary;
    if (state === "APPLYING") { emitStatus("BUSY_APPLYING", "Wait for the current Apply operation to finish before scanning again."); return; }
    if (state === "ANALYZING" || state === "CANCELLING") { outlet(1, "cancel"); }
    activeAnalysisJobId = null; activeAnalysisSettings = null;
    /* Re-resolve the enclosing track and downstream devices on every scan so
       adding, deleting, moving, or reordering racks cannot leave stale IDs. */
    discoverRacks(); if (!rackCandidates.length) { return; }
    setState("SCANNING"); emitStatus("SCANNING", "Scanning rack…"); chainByRegion = {}; plan = null; jobId = newId(); rack = makeApi(rackCandidates[targetRackIndex].id);
    if (!rack.id) { fail("TARGET_RACK_MISSING", "The selected Drum Rack no longer exists."); return; }
    snapshot = {schemaVersion: 1, jobId: jobId, createdAt: new Date().toISOString(), track: {displayName: V.string(get(makeApi(trackPath), "name")), sessionPath: trackPath}, rack: {displayName: V.string(get(rack, "name")), sessionId: Number(rack.id), sessionPath: apiPath(rack)}, regions: [], skippedPads: []};
    padIds = V.idList(get(rack, "drum_pads"));
    if (!padIds.length) { fail("DRUM_PADS_UNAVAILABLE", "Live did not expose the selected rack's top-level Drum Pads."); return; }
    for (i = 0; i < padIds.length; i += 1) {
        pad = makeApi(padIds[i]); chains = V.idList(get(pad, "chains"));
        if (chains.length === 0) { continue; }
        if (chains.length !== 1) { snapshot.skippedPads.push({padNote: V.number(get(pad, "note"), i), reasonCode: "MULTIPLE_CHAINS", message: "Pad contains more than one chain."}); reasonCounts.MULTIPLE_CHAINS = (reasonCounts.MULTIPLE_CHAINS || 0) + 1; continue; }
        result = extractRegion(jobId, rack, pad, i, chains[0]);
        if (result.skip) { snapshot.skippedPads.push(result.skip); reasonCounts[result.skip.reasonCode] = (reasonCounts[result.skip.reasonCode] || 0) + 1; }
        else { snapshot.regions.push(result.region); sourceSeen[result.region.source.path] = true; }
    }
    summary = {populatedPads: snapshot.regions.length + snapshot.skippedPads.length, analyzablePads: snapshot.regions.length, skippedPads: snapshot.skippedPads.length, uniqueSources: Object.keys(sourceSeen).length, reasonCounts: reasonCounts};
    if (snapshot.regions.length) {
        setState("SCAN_READY"); emitStatus("SCAN_COMPLETE", countLabel(summary.analyzablePads, "slice", "slices") + " ready · " + countLabel(summary.uniqueSources, "source", "sources") + (summary.skippedPads ? " · " + countLabel(summary.skippedPads, "skipped", "skipped") : ""), summary);
    } else {
        setState("READY_TO_SCAN"); emitStatus("NO_ANALYZABLE_PADS", "No supported slices found in this rack" + (summary.skippedPads ? " · " + countLabel(summary.skippedPads, "pad skipped", "pads skipped") : ""), summary);
    }
    outlet(2, "snapshot", JSON.stringify(snapshot));
}

/* Primary device action: refresh the rack snapshot first, then immediately
   start analysis when the scan found supported slices. Keeping scan() public
   preserves the explicit Refresh control and the existing integration API. */
function scanandanalyze() {
    scan();
    if (state === "SCAN_READY") { analyze(); }
}

function analyze() {
    if (state !== "SCAN_READY" || !snapshot || !snapshot.regions.length) { return; }
    activeAnalysisJobId = snapshot.jobId; activeAnalysisSettings = copyValue(analysisSettings); setState("ANALYZING");
    emitStatus("ANALYSIS_STARTED", "Analyzing " + countLabel(snapshot.regions.length, "slice", "slices") + "…");
    outlet(1, "analyze", JSON.stringify({snapshot: snapshot, settings: activeAnalysisSettings}));
}
function cancel() { if (state !== "ANALYZING") { return; } setState("CANCELLING"); outlet(1, "cancel"); }
function clearcache() { if (state === "ANALYZING" || state === "CANCELLING" || state === "APPLYING") { emitStatus("BUSY", "Wait for the current operation before clearing the cache."); return; } outlet(1, "clear_cache"); }
function checkbackend() { if (state === "ANALYZING" || state === "CANCELLING" || state === "APPLYING") { emitStatus("BUSY", "Wait for the current operation before checking the backend."); return; } outlet(1, "health", "adtof"); }

function result_json() { receiveNode("result", arrayfromargs(arguments).join(" ")); }
function error_json() { receiveNode("error", arrayfromargs(arguments).join(" ")); }
function progress_json() { receiveNode("progress", arrayfromargs(arguments).join(" ")); }
function receiveNode(kind, json) {
    var payload, scoped;
    try { payload = typeof json === "string" ? JSON.parse(json) : json; } catch (exception) { fail("MALFORMED_NODE_RESPONSE", "The analysis service returned malformed data."); return; }
    if (!payload || typeof payload !== "object") { fail("MALFORMED_NODE_RESPONSE", "The analysis service returned malformed data."); return; }
    scoped = payload.jobId != null;
    if (scoped && String(payload.jobId) !== String(activeAnalysisJobId || "")) { return; }
    if (kind === "error") {
        if (payload.code === "ANALYSIS_CANCELLED") {
            if (state === "CANCELLING") { activeAnalysisJobId = null; activeAnalysisSettings = null; setState(snapshot && snapshot.regions.length ? "SCAN_READY" : "READY_TO_SCAN"); emitStatus("ANALYSIS_CANCELLED", "Analysis was cancelled."); }
            return;
        }
        if (scoped) { activeAnalysisSettings = null; }
        fail(payload.code || "ANALYSIS_ERROR", payload.message || "Analysis failed.", payload.details); return;
    }
    if (kind === "progress") {
        if (state !== "ANALYZING" && state !== "CANCELLING") { return; }
        outlet(0, "progress", Number(payload.completed || 0), Math.max(1, Number(payload.total || 1)), payload.message || "Analyzing"); return;
    }
    if (!snapshot || state !== "ANALYZING" || !scoped || String(payload.jobId) !== String(snapshot.jobId) || payload.requestId == null) { return; }
    buildPlan(payload.predictions || [], activeAnalysisSettings || analysisSettings); activeAnalysisJobId = null; activeAnalysisSettings = null; setState("REVIEW_READY"); emitStatus("ANALYSIS_COMPLETE", countLabel(plan.rows.length, "slice", "slices") + " analyzed" + (countUnknown(plan.rows) ? " · " + countLabel(countUnknown(plan.rows), "uncertain", "uncertain") : "") + (snapshot.skippedPads.length ? " · " + countLabel(snapshot.skippedPads.length, "skipped", "skipped") : "") + " · Ready to review"); outlet(2, "plan", JSON.stringify(plan));
}

function buildPlan(predictions, settingsForJob) {
    var byId = {}, seed = [], generated, i, region, prediction;
    for (i = 0; i < predictions.length; i += 1) { byId[predictions[i].regionId] = predictions[i]; }
    for (i = 0; i < snapshot.regions.length; i += 1) { region = snapshot.regions[i]; prediction = byId[region.regionId] || {classes: ["unknown"], scores: {}, decision: "analysis_error"}; seed.push({regionId: region.regionId, oldName: region.originalChainName, classes: prediction.classes, sourceFingerprint: V.sha256(region.source.path), sourceStartFrame: region.source.startFrame, padNote: region.padNote}); }
    generated = Naming.generate(seed, settingsForJob && settingsForJob.namingOptions || {numbering: "duplicates"}); plan = {schemaVersion: 1, jobId: snapshot.jobId, rows: []};
    for (i = 0; i < seed.length; i += 1) { region = snapshot.regions[i]; prediction = byId[region.regionId] || {classes: ["unknown"], scores: {}, decision: "analysis_error", warnings: []}; plan.rows.push({regionId: region.regionId, padNote: region.padNote, oldName: region.originalChainName, proposedName: generated[i].generatedName, effectiveName: generated[i].effectiveName, keepOriginal: !!generated[i].preserveOriginal, autoKeepOriginal: !!generated[i].preserveOriginal, userEdited: false, classes: prediction.classes, scores: prediction.scores, decision: prediction.decision, status: "ready", warnings: prediction.warnings || []}); }
}
function countUnknown(rows) { var n = 0, i; for (i = 0; i < rows.length; i += 1) { if (rows[i].classes.length === 1 && rows[i].classes[0] === "unknown") { n += 1; } } return n; }

function copyValue(value) { return JSON.parse(JSON.stringify(value)); }
function validateRegion(region, row, storedRef) {
    var ref = storedRef || chainByRegion[region.regionId], rack, padIds, pad = null, chains, chain, found, simpler, sampleIds, sample, current, i;
    if (!ref) { return {ok: false, stale: true, code: "CHAIN_REFERENCE_MISSING"}; }
    rack = makeApi(ref.rackId);
    if (!rack.id || Number(rack.id) !== Number(ref.rackId)) { return {ok: false, stale: true, code: "TARGET_RACK_MISSING"}; }
    if (ref.rackPath && apiPath(rack) !== ref.rackPath) { return {ok: false, stale: true, code: "TARGET_RACK_MOVED"}; }
    padIds = V.idList(get(rack, "drum_pads"));
    for (i = 0; i < padIds.length; i += 1) {
        pad = makeApi(padIds[i]);
        if (V.number(get(pad, "note"), -1) === Number(region.padNote)) { break; }
        pad = null;
    }
    if (!pad) { return {ok: false, stale: true, code: "PAD_MISSING"}; }
    if (ref.padId && Number(pad.id) !== Number(ref.padId)) { return {ok: false, stale: true, code: "PAD_IDENTITY_CHANGED"}; }
    chains = V.idList(get(pad, "chains"));
    if (chains.length !== 1 || Number(chains[0]) !== Number(ref.chainId)) { return {ok: false, stale: true, code: "PAD_CHAIN_CHANGED"}; }
    chain = makeApi(ref.chainId); if (!chain.id) { return {ok: false, stale: true, code: "CHAIN_MISSING"}; }
    found = findReachableSimplers(ref.chainId, 8); if (found.incomplete) { return {ok: false, stale: true, code: "SIMPLER_TRAVERSAL_INCOMPLETE"}; } if (found.matches.length !== 1) { return {ok: false, stale: true, code: "SIMPLER_STRUCTURE_CHANGED"}; }
    simpler = makeApi(found.matches[0].id); sampleIds = V.idList(get(simpler, "sample"));
    if (sampleIds.length !== 1) { return {ok: false, stale: true, code: "SAMPLE_OBJECT_CHANGED"}; }
    sample = makeApi(sampleIds[0]);
    if (V.string(get(sample, "file_path")) !== region.source.path || V.number(get(sample, "sample_rate"), 0) !== region.source.sampleRate || V.number(get(sample, "start_marker"), -1) !== region.source.startFrame || V.number(get(sample, "end_marker"), -1) !== region.source.endFrame) { return {ok: false, stale: true, code: "SAMPLE_IDENTITY_CHANGED"}; }
    current = V.string(get(chain, "name")); if (current !== row.oldName && !overwriteConflicts) { return {ok: false, stale: false, conflict: true, code: "CHAIN_NAME_CONFLICT", currentName: current}; }
    return {ok: true, chain: chain, currentName: current};
}

function apply() {
    var i, check, task;
    if (state !== "REVIEW_READY" || !plan) { return; }
    setState("APPLYING");
    for (i = 0; i < plan.rows.length; i += 1) { check = validateRegion(snapshot.regions[i], plan.rows[i]); if (check.stale) { fail("PLAN_STALE", "The rack or slice markers changed. Analyze again before applying.", {regionId: plan.rows[i].regionId, reason: check.code}); return; } }
    task = new Task(function () {
        var row, validation, name, readback, writes = [], failures = 0, unchanged = 0, newApply;
        /* A Live edit can occur after the button callback but before this
           deferred task. Revalidate the complete plan again before any write. */
        for (i = 0; i < plan.rows.length; i += 1) {
            validation = validateRegion(snapshot.regions[i], plan.rows[i]);
            if (validation.stale) { fail("PLAN_STALE", "The rack or slice markers changed. Analyze again before applying.", {regionId: plan.rows[i].regionId, reason: validation.code}); outlet(2, "plan", JSON.stringify(plan)); return; }
        }
        for (i = 0; i < plan.rows.length; i += 1) {
            row = plan.rows[i]; validation = validateRegion(snapshot.regions[i], row);
            if (row.keepOriginal) { row.status = "kept"; unchanged += 1; continue; }
            if (validation.stale) { row.status = "stale"; failures += 1; continue; }
            if (validation.conflict) { row.status = "conflict"; failures += 1; continue; }
            name = Naming.validateUserName(row.effectiveName, 31); if (!name.ok) { row.status = "error"; failures += 1; continue; }
            /* A same-name set is not an Apply. Treat it as unchanged so a
               previous real Apply remains available to Revert. */
            if (name.value === validation.currentName) { row.status = "unchanged"; unchanged += 1; continue; }
            try {
                validation.chain.set("name", name.value); readback = V.string(get(validation.chain, "name"));
                if (readback === name.value) {
                    writes.push({regionId: row.regionId, padNote: row.padNote, oldName: row.oldName, appliedName: name.value, region: copyValue(snapshot.regions[i]), ref: copyValue(chainByRegion[row.regionId])}); row.status = "applied";
                } else { row.status = "error"; failures += 1; }
            } catch (exception) { row.status = "error"; failures += 1; }
        }
        if (writes.length) {
            newApply = {applyId: newId(), rackFingerprint: V.sha256(snapshot.rack.sessionPath + "\0" + snapshot.jobId), writes: writes}; lastApply = newApply;
            setState("APPLIED"); emitStatus(failures ? "PARTIAL_APPLY" : "APPLY_COMPLETE", countLabel(writes.length, "name", "names") + " applied" + (failures ? " · " + countLabel(failures, "skipped or failed", "skipped or failed") : ""));
        } else if (!failures && unchanged) { setState(lastApply && lastApply.writes.length ? "APPLIED" : "REVIEW_READY"); emitStatus("APPLY_NO_CHANGES", "No chain names needed changing; any previous verified Apply remains available to Revert."); }
        else { fail("APPLY_FAILED", "No chain names were changed."); }
        outlet(2, "plan", JSON.stringify(plan));
    }, this); task.schedule(0);
}

function revert() {
    var applyRecord, remaining = [], restored = 0, i, write, row, check, chain, current, task;
    if (state === "ANALYZING" || state === "CANCELLING" || state === "SCANNING" || state === "APPLYING") { emitStatus("BUSY", "Wait for the current operation before reverting names."); return; }
    if (!lastApply || !lastApply.writes.length) { return; }
    /* Capture the exact apply record and enter a busy state before deferring.
       Without this, two fast button presses can schedule two reverts against
       the same mutable global record, and a revert can also clobber an active
       analysis state before its result arrives. */
    applyRecord = lastApply;
    setState("APPLYING");
    task = new Task(function () {
        for (i = 0; i < applyRecord.writes.length; i += 1) {
            write = applyRecord.writes[i];
            if (!write.region || !write.ref) { remaining.push(write); continue; }
            check = validateRegion(write.region, {oldName: write.appliedName}, write.ref); if (!check.ok) { remaining.push(write); continue; }
            chain = check.chain; current = V.string(get(chain, "name")); if (current !== write.appliedName) { remaining.push(write); continue; }
            try {
                chain.set("name", write.oldName);
                if (V.string(get(chain, "name")) === write.oldName) { restored += 1; row = rowById(write.regionId); if (row) { row.status = "reverted"; } }
                else { remaining.push(write); }
            } catch (exception) { remaining.push(write); }
        }
        applyRecord.writes = remaining;
        if (lastApply === applyRecord) {
            if (!remaining.length) {
                lastApply = null;
                setState(plan ? "REVIEW_READY" : (snapshot && snapshot.regions && snapshot.regions.length ? "SCAN_READY" : "READY_TO_SCAN"));
            } else { setState("APPLIED"); }
        }
        emitStatus(remaining.length ? "PARTIAL_REVERT" : "REVERT_COMPLETE", countLabel(restored, "name", "names") + " restored");
        if (plan) { outlet(2, "plan", JSON.stringify(plan)); }
    }, this); task.schedule(0);
}
function rowById(id) { var i; for (i = 0; plan && i < plan.rows.length; i += 1) { if (plan.rows[i].regionId === id) { return plan.rows[i]; } } return null; }
function editname() {
    var args = arrayfromargs(arguments), regionId = args.shift(), value, row, checked;
    if (state !== "REVIEW_READY") { return; }
    if (args[0] === "text") { args.shift(); }
    value = args.join(" "); row = rowById(String(regionId)); checked = Naming.validateUserName(value, 31);
    if (row && checked.ok) { row.effectiveName = checked.value; row.userEdited = true; outlet(2, "plan", JSON.stringify(plan)); }
    else if (row) { emitStatus(checked.code, checked.message); }
}
function keeporiginal(regionId, enabled) { var row; if (state !== "REVIEW_READY") { return; } row = rowById(String(regionId)); if (row) { row.keepOriginal = Number(enabled) === 1; row.autoKeepOriginal = false; outlet(2, "plan", JSON.stringify(plan)); } }
function resetRowState(row) { if (row) { row.effectiveName = row.proposedName; row.userEdited = false; row.keepOriginal = !!row.autoKeepOriginal; } }
function resetrow(regionId) { var row; if (state !== "REVIEW_READY") { return; } row = rowById(String(regionId)); resetRowState(row); if (row) { outlet(2, "plan", JSON.stringify(plan)); } }
function resetall() { var i; if (state !== "REVIEW_READY") { return; } for (i = 0; plan && i < plan.rows.length; i += 1) { resetRowState(plan.rows[i]); } if (plan) { outlet(2, "plan", JSON.stringify(plan)); } }
function overwrite(value) { overwriteConflicts = Number(value) === 1; }
function settings_json() { var parsed; try { parsed = JSON.parse(arrayfromargs(arguments).join(" ")); if (parsed && parsed.backend) { analysisSettings = parsed; } } catch (exception) { emitStatus("INVALID_SETTINGS", "Settings could not be applied."); } }
function pythonpath() { var args = arrayfromargs(arguments); if (state === "ANALYZING" || state === "CANCELLING" || state === "APPLYING") { emitStatus("BUSY", "Wait for the current operation before changing the backend."); return; } if (args[0] === "text") { args.shift(); } outlet(1, "configure_python", args.join(" ")); }
function refresh() { if (state !== "APPLYING") { discoverRacks(); } }

function repairpresentation() {
    var layouts = [
        [[50, 105, 73, 18], [8, 7, 73, 20]],
        [[135, 105, 190, 20], [80, 6, 190, 22]],
        [[50, 190, 55, 22], [278, 6, 55, 22]],
        [[120, 190, 65, 22], [338, 6, 65, 22]],
        [[195, 190, 55, 22], [408, 6, 55, 22]],
        [[265, 190, 55, 22], [468, 6, 55, 22]],
        [[335, 190, 110, 22], [528, 6, 110, 22]],
        [[470, 190, 87, 22], [643, 6, 87, 22]],
        [[570, 190, 67, 22], [735, 6, 67, 22]],
        [[355, 430, 500, 18], [8, 34, 794, 20]],
        [[355, 460, 300, 41], [8, 57, 794, 41]]
    ];
    var box = this.patcher.firstobject, current, i, j, match, ok, repaired = 0;
    while (box) {
        try {
            current = box.getboxattr("patching_rect");
            for (i = 0; i < layouts.length; i += 1) {
                match = layouts[i][0]; ok = current && current.length === 4;
                for (j = 0; ok && j < 4; j += 1) { ok = Math.abs(Number(current[j]) - match[j]) < 0.01; }
                if (ok) {
                    box.setboxattr("presentation", 1);
                    box.setboxattr("presentation_rect", layouts[i][1]);
                    repaired += 1;
                    break;
                }
            }
        } catch (exception) {}
        box = box.nextobject;
    }
    emitStatus(repaired === layouts.length ? "LAYOUT_REPAIRED" : "LAYOUT_REPAIR_INCOMPLETE", repaired + " presentation object(s) positioned.");
}

function anything() {
    var args = arrayfromargs(arguments), joined = args.join(" ");
    if (inlet === 1) {
        if (messagename === "result") { receiveNode("result", joined); }
        else if (messagename === "error") { receiveNode("error", joined); }
        else if (messagename === "progress") { receiveNode("progress", joined); }
        else if (messagename === "health") { emitStatus("BACKEND_READY", "ADTOF backend is ready."); }
        else if (messagename === "python_configured") { emitStatus("BACKEND_CONFIGURED", "The Python backend was validated and configured."); }
        else if (messagename === "cache_cleared") { emitStatus("CACHE_CLEARED", "The local analysis cache was cleared."); }
    }
}
